__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/88456805407ee0e9.js",
  "static/chunks/turbopack-ffe93b5dca4226c5.js"
])
