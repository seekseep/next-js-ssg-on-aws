__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/88456805407ee0e9.js",
  "static/chunks/turbopack-9d2737aec56c44ac.js"
])
